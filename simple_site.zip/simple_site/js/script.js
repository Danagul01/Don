// Небольшой скрипт для демо
document.addEventListener('DOMContentLoaded', function(){
  console.log('Demo site loaded');
});
